// Copyright (c) 2014 GitHub, Inc.
// Use of this source code is governed by the MIT license that can be
// found in the LICENSE file.

#ifndef BRAVE_COMMON_CONVERTERS_STRING16_CONVERTER_H_
#define BRAVE_COMMON_CONVERTERS_STRING16_CONVERTER_H_

#include "base/strings/string16.h"
#include "gin/converter.h"

namespace gin {

template<>
struct Converter<base::string16> {
  static v8::Local<v8::Value> ToV8(v8::Isolate* isolate,
                                    const base::string16& val) {
    return v8::String::NewFromTwoByte(
        isolate, reinterpret_cast<const uint16_t*>(val.data()),
        v8::String::kNormalString, val.size());
  }
  static bool FromV8(v8::Isolate* isolate,
                     v8::Local<v8::Value> val,
                     base::string16* out) {
    if (!val->IsString())
      return false;

    v8::String::Value s(val);
    out->assign(reinterpret_cast<const base::char16*>(*s), s.length());
    return true;
  }
};

inline v8::Local<v8::String> StringToV8(
    v8::Isolate* isolate,
    const base::string16& input) {
  return ConvertToV8(isolate, input).As<v8::String>();
}

}  // namespace gin

#endif  // BRAVE_COMMON_CONVERTERS_STRING16_CONVERTER_H_
