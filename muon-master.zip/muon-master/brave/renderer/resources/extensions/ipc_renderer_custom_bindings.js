const ipc_utils = require('ipc_utils')
exports.$set('binding', ipc_utils)
