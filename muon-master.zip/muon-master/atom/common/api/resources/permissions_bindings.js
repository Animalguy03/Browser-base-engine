var binding = {
  contains: function(cb) {
    if (cb) {
      cb(true)
    }
  }
}

exports.binding = binding;
