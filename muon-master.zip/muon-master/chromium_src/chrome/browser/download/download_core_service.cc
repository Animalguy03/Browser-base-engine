// Copyright 2017 The Brave Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

#include "chrome/browser/download/download_core_service.h"

// static
int DownloadCoreService::NonMaliciousDownloadCountAllProfiles() {
  return 0;
}
